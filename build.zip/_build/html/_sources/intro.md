# Bayesian-ML

## What is this book?

This book has a two fold visions: 

1. An attempt to provide simplified and detailed math for several Bayesian models under the same framework.
2. Implement proof of concept of all those models using a single tool: `PyTorch`.

I believe that bringing all models under the same framework will make the comparison easy and clarify the concepts better and readers will have a minimal working example code in `PyTorch`.
