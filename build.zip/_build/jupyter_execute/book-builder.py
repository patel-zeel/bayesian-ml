#!/usr/bin/env python
# coding: utf-8

# In[3]:


get_ipython().system('pip install -qq jupyter-book')


# In[4]:


get_ipython().system('jupyter-book build ./')


# In[5]:


get_ipython().system('jupyter notebook list')

